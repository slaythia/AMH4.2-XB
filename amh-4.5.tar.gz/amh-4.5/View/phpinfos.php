<?php include('header.php'); ?>

<style>
body {
display:none;
}
</style>
<div id="body">
<h2 style="font-size: 20px;">AMH » PHPINFO </h2>

<?php
	phpinfo();
?>

</div>
<?php include('footer.php'); ?>

<style>
body, td, th, h1, h2 {
font-family: Arial,宋体;
}
a:link {
color: #009;
text-decoration: none;
background-color: transparent;
}
.center {
text-align: left;
display:block;
}
.center table {
margin-left: 0px;
margin-right: auto;
text-align: left;
}
hr {
margin-left: 0px;
}
td, th {
font-size: 99%;
text-shadow: none;
}
body {
display:block;
}
</style>
